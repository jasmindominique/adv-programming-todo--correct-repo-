// we don't need to refer to this later, so don't really
// need to assign it to a variable
const todo = new TodoList('.todo-list');